from __future__ import annotations

import asyncio
from pathlib import Path

import typer
from agents import Runner
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel

from crisai.agents.factory import AgentFactory
from crisai.config import load_settings
from crisai.registry import Registry
from crisai.runtime import MultiServerContext, RuntimeManager
from crisai.tracing import append_trace

app = typer.Typer(help="crisAI CLI")
console = Console()


def _load_registry():
    settings = load_settings()
    registry = Registry(settings.registry_dir)
    server_specs = {s.id: s for s in registry.load_servers() if s.enabled}
    agent_specs = {a.id: a for a in registry.load_agents()}
    return settings, registry, server_specs, agent_specs


def _build_agent(factory: AgentFactory, runtime: RuntimeManager, agent_spec, server_specs):
    servers = []
    for server_id in agent_spec.allowed_servers:
        spec = server_specs.get(server_id)
        if spec:
            servers.append(runtime.build_server(spec))
    return servers


@app.command("list-servers")
def list_servers() -> None:
    settings, _, server_specs, _ = _load_registry()
    for spec in server_specs.values():
        console.print(f"{spec.id} | enabled={spec.enabled} | transport={spec.transport} | tags={','.join(spec.tags)}")


@app.command("list-agents")
def list_agents() -> None:
    _, _, _, agent_specs = _load_registry()
    for spec in agent_specs.values():
        console.print(f"{spec.id} | model={spec.model} | servers={','.join(spec.allowed_servers)}")


async def _run_single(message: str, agent_id: str) -> str:
    settings, _, server_specs, agent_specs = _load_registry()
    if not settings.openai_api_key:
        raise typer.BadParameter("OPENAI_API_KEY is not set.")
    root_dir = Path.cwd()
    runtime = RuntimeManager(root_dir)
    factory = AgentFactory(root_dir)
    agent_spec = agent_specs[agent_id]
    servers = _build_agent(factory, runtime, agent_spec, server_specs)
    async with MultiServerContext(servers) as active_servers:
        agent = factory.build_agent(agent_spec, active_servers)
        result = await Runner.run(agent, message)
        return str(result.final_output)


async def _run_pipeline(message: str, verbose: bool) -> str:
    settings, _, server_specs, agent_specs = _load_registry()
    if not settings.openai_api_key:
        raise typer.BadParameter("OPENAI_API_KEY is not set.")

    root_dir = Path.cwd()
    runtime = RuntimeManager(root_dir)
    factory = AgentFactory(root_dir)
    trace_file = settings.log_dir / "agent_trace.log"

    discovery_spec = agent_specs["discovery"]
    design_spec = agent_specs["design"]
    review_spec = agent_specs["review"]
    orchestrator_spec = agent_specs["orchestrator"]

    all_server_ids = sorted({*discovery_spec.allowed_servers, *design_spec.allowed_servers, *review_spec.allowed_servers})
    servers = [runtime.build_server(server_specs[sid]) for sid in all_server_ids if sid in server_specs]

    async with MultiServerContext(servers) as active_servers:
        append_trace(trace_file, "USER INPUT", message)

        if verbose:
            console.print(Panel.fit("Running Discovery Agent", style="cyan"))
        discovery_agent = factory.build_agent(discovery_spec, active_servers)
        discovery_prompt = f"""
User request:
{message}

Task:
Inspect the workspace and retrieve the most relevant material for this request.
Return:
1. relevant files
2. extracted facts
3. assumptions
4. constraints
5. decisions already present
6. missing information
"""
        discovery_result = await Runner.run(discovery_agent, discovery_prompt)
        discovery_text = str(discovery_result.final_output)
        append_trace(trace_file, "DISCOVERY OUTPUT", discovery_text)
        if verbose:
            console.print(Markdown(f"## Discovery Agent\n\n{discovery_text}"))

        if verbose:
            console.print(Panel.fit("Running Design Agent", style="green"))
        design_agent = factory.build_agent(design_spec, active_servers)
        design_prompt = f"""
User request:
{message}

Discovery findings:
{discovery_text}

Task:
Produce the best possible architecture, design, or documentation response for the user's request.
Where a diagram would help, generate Mermaid.
"""
        design_result = await Runner.run(design_agent, design_prompt)
        design_text = str(design_result.final_output)
        append_trace(trace_file, "DESIGN OUTPUT", design_text)
        if verbose:
            console.print(Markdown(f"## Design Agent\n\n{design_text}"))

        if verbose:
            console.print(Panel.fit("Running Review Agent", style="yellow"))
        review_agent = factory.build_agent(review_spec, active_servers)
        review_prompt = f"""
User request:
{message}

Discovery findings:
{discovery_text}

Draft design response:
{design_text}

Task:
Critically review the draft.
Highlight governance gaps, ownership gaps, NFR or assurance gaps, delivery risks, and suggested improvements.
"""
        review_result = await Runner.run(review_agent, review_prompt)
        review_text = str(review_result.final_output)
        append_trace(trace_file, "REVIEW OUTPUT", review_text)
        if verbose:
            console.print(Markdown(f"## Review Agent\n\n{review_text}"))

        orchestrator_agent = factory.build_agent(orchestrator_spec, active_servers)
        final_prompt = f"""
User request:
{message}

Discovery findings:
{discovery_text}

Draft design response:
{design_text}

Review feedback:
{review_text}

Task:
Produce the final answer to the user.
Use the design output as the main body, but improve it using the review feedback.
Do not mention internal pipeline stages unless the user explicitly asked for them.
"""
        final_result = await Runner.run(orchestrator_agent, final_prompt)
        final_text = str(final_result.final_output)
        append_trace(trace_file, "FINAL OUTPUT", final_text)
        return final_text


@app.command()
def ask(
    message: str = typer.Option(..., "--message", "-m"),
    agent_id: str = typer.Option("orchestrator", "--agent"),
    pipeline: bool = typer.Option(False, "--pipeline", help="Run the visible discovery/design/review/orchestrator pipeline."),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    async def _run() -> None:
        text = await (_run_pipeline(message, verbose) if pipeline else _run_single(message, agent_id))
        console.print(Markdown(text))
    asyncio.run(_run())
